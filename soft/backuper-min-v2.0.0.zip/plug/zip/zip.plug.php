<?php
require_once dirname(__FILE__) . '/zip.php';
function plug_zip($zip_path, $dir_name)
{
    set_time_limit(60);
    $zip = new PclZip($zip_path);
    $list = $zip->create($dir_name, PCLZIP_OPT_ADD_PATH, "./");
    if (0 != $list) {
        return true;
    }
}
function plug_unzip($zip_path, $dir_name)
{
    set_time_limit(60);
    $j = new PclZip($zip_path);
    $l = $j->extract(PCLZIP_OPT_PATH, $dir_name);
    if (0 != $l) {
        return true;
    }
}
